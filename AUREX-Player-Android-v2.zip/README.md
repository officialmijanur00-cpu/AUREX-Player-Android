# AUREX Player

A native Android video-player starter using VideoLAN libVLC.

## Build
The GitHub Actions workflow builds a debug APK on pushes to `main` or when manually started.

## Current scope
- Native Android application (not a website wrapper)
- libVLC playback engine for broad container/codec support, subject to device and library capabilities
- Local video selection through Android's document picker
- Basic play/pause controls
- No advertising SDK or subscription/payment flow

This is the first playable foundation, not yet a complete VLC replacement. Subtitle selection, audio-track menus, picture-in-picture, playback resume, AUREX REMEMBER, and AUREX IMMERSION are planned follow-up features.
