package com.aurex.player;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;
    private LibVLC libVLC;
    private MediaPlayer mediaPlayer;
    private TextView statusText;
    private Uri currentUri;
    private final Handler handler = new Handler();

    @Override public void onCreate(Bundle state) { super.onCreate(state); showSplash(); }

    private void showSplash() {
        setContentView(R.layout.activity_splash);
        View brand = findViewById(R.id.splash_brand);
        brand.setAlpha(0f); brand.setScaleX(.88f); brand.setScaleY(.88f);
        brand.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(850)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        handler.postDelayed(this::showHome, 1650);
    }

    private void showHome() {
        if (isFinishing()) return;
        setContentView(R.layout.activity_main);
        VLCVideoLayout videoLayout = findViewById(R.id.video_layout);
        statusText = findViewById(R.id.status_text);
        Button open = findViewById(R.id.open_button), play = findViewById(R.id.play_button);
        open.setOnClickListener(v -> openPicker());
        play.setOnClickListener(v -> {
            if (mediaPlayer == null || currentUri == null) Toast.makeText(this,"Choose a video first",Toast.LENGTH_SHORT).show();
            else if (mediaPlayer.isPlaying()) { mediaPlayer.pause(); play.setText("RESUME"); }
            else { mediaPlayer.play(); play.setText("PAUSE"); }
        });
        findViewById(R.id.videos_section).setOnClickListener(v -> openPicker());
        findViewById(R.id.music_section).setOnClickListener(v -> Toast.makeText(this,"Music library is planned for the next build.",Toast.LENGTH_SHORT).show());
        findViewById(R.id.history_section).setOnClickListener(v -> Toast.makeText(this,"Playback history is planned for the next build.",Toast.LENGTH_SHORT).show());
        findViewById(R.id.menu_button).setOnClickListener(v -> Toast.makeText(this,"AUREX menu is planned for the next build.",Toast.LENGTH_SHORT).show());
        ArrayList<String> options = new ArrayList<>(); options.add("--audio-time-stretch");
        libVLC = new LibVLC(this, options); mediaPlayer = new MediaPlayer(libVLC);
        mediaPlayer.attachViews(videoLayout, null, false, false);
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_VIDEO);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_VIDEO && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            currentUri=data.getData();
            try { getContentResolver().takePersistableUriPermission(currentUri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(SecurityException ignored) { }
            Media media=new Media(libVLC,currentUri); mediaPlayer.setMedia(media); media.release(); mediaPlayer.play();
            statusText.setText("NOW PLAYING  •  "+currentUri.getLastPathSegment());
        }
    }
    @Override protected void onStop() { super.onStop(); if(mediaPlayer!=null) mediaPlayer.pause(); }
    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if(mediaPlayer!=null) { mediaPlayer.stop(); mediaPlayer.detachViews(); mediaPlayer.release(); }
        if(libVLC!=null) libVLC.release(); super.onDestroy();
    }
}
